
"""Importing modules"""
from datetime import datetime
import re
import socket
from flask import render_template, Flask, session, redirect, flash, request
from passlib.hash import sha256_crypt

def password_encode(password):
    """password Encode via sha256"""
    h_pass = sha256_crypt.hash(password)
    if h_pass:
        return h_pass
    return None

def write_credentials(username, password):
    """Write credentials to file"""
    file_name="credentials.txt"
    with open(file_name,'a', encoding="utf-8") as file:
        h_password = password_encode(password)
        file.write(':'.join((username, h_password)))
        file.write('\n')

def write_logs(_msg):
    """for log file"""
    h_name = socket.gethostname()
    ip_address = socket.gethostbyname(h_name)
    _datetime = datetime.now()
    file_name="logs.txt"
    with open(file_name,'a',  encoding="utf-8") as file:
        file.write('-'.join([str(_datetime), _msg, ip_address]))
        file.write('\n')

def put_in_list():

    """for building Dict"""
    _list = []
    with open('credentials.txt', encoding="utf-8") as file:
        r_file = file.read()
        l_items = r_file.strip()
        s_items = l_items.split('\n')

        for rec in s_items:
            regx = r"\S"
            if re.search(regx, rec):
                _list.append(rec)
        return _list

def password_existance(password):
    """for password existance """
    _list = put_in_list()
    passwords = []
    status = []
    if _list is not None:
        for i, _li in enumerate(_list):
            s_rec=str(_li).split(",")
            for j in s_rec:
                passwords.append([j.split(":")[1], i])
    for val in (passwords):
        status.append([sha256_crypt.verify(password, val[0]), val[1]])
    for pas in passwords:
        if sha256_crypt.verify(password, pas[0]):
            return pas[0],pas[1]
        return None

def name_existance(name):
    """method for searching name existance"""
    _list = put_in_list()
    names = []
    if _list is not None:
        for i, _li in enumerate(_list):
            s_rec = str(_li).split(",")
            for j in s_rec:
                if j.split(":")[0] == name:
                    names.append([j.split(":")[0], i])
    for u_name in names:
        if name == u_name[0]:
            return u_name[0], u_name[1]
        return None

def password_encryption(password):
    """for password encryption"""
    reg = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{8,20}$"
    pattern = re.compile(reg)
    search = re.search(pattern, password)
    return search

def formate_password():
    """for password formate"""
    passwordslist = []
    with open('CommonPassword.txt', encoding="utf-8") as file:
        lines = file.readlines()
        for i in lines:
            passwordslist.append(i.replace("\n", ""))
    return passwordslist


APP = Flask(__name__)
APP.config['SECRET_KEY'] = 'thesecretcode8'


@APP.route('/', methods=['GET', 'POST'])
def index():
    """this is for home page"""
    return render_template('index.html')

@APP.route("/dashboard", methods=['GET', 'POST'])
def dashboard():
    """this is for main dashboard"""
    return render_template('Dashboard.html')

@APP.route('/Register', methods=['GET', 'POST'])
def register():
    """this is for registration page"""

    if request.method == 'POST':
        u_username = request.form.get('username')
        u_password = request.form.get('Password')
        f_password = formate_password()
        r_username=name_existance(u_username)
        r_password=password_existance(u_password)
        print(r_username,r_password)
        if r_username is None and r_password is None:
            p_validation=password_encryption(u_password)
            if p_validation is None or u_password in f_password:
                flash("Choose a stronger password")
            else:
                write_credentials(u_username, u_password)
                flash("Account is successfuly Created")
                return redirect("/login")
        if r_username is not None and r_password is None:
            p_val=password_encryption(u_password)
            if p_val is not None:
                write_credentials(u_username, u_password)
                flash("Account is Successully Created")
                return redirect("/login")
            flash("Weak password choose stronger")
        if r_username is not None and r_password is not None:
            if r_username[1] == r_password[1]:
                flash("You have aleady an account")
            else:
                write_credentials(u_username,u_password)
                flash("Account is successfuly created")
                return redirect("/login")
        if r_username is None and r_password is not None:
            write_credentials(u_username,u_password)
            flash("Account is successfully created")
            return redirect("/login")
    return render_template('register.html')


@APP.route('/login', methods=['GET', 'POST'])
def login():
    """This is for login  page"""
    error = ""
    if request.method == 'POST':
        name = request.form.get('username')
        pas = request.form.get('Password')
        u_exist=name_existance(name)
        p_exist=password_existance(pas)
        print(u_exist,p_exist)
        if u_exist is not None and p_exist is not None:
            if sha256_crypt.verify(pas,p_exist[0]) or u_exist[1] == p_exist[1]:
                session['email'] = name
                write_logs("Succes")
                return redirect("/dashboard")
        else:
            write_logs("You need to reigster first")
            error = "You need to Register first"
            flash(error)
    return render_template('login.html')

@APP.route("/logout", methods=['GET', 'POST'])
def logout():
    """this is for log out page"""
    session.pop('email', None)
    return render_template('login.html')

@APP.route("/update_password", methods=['GET', 'POST'])
def update_password():
    """this is for update password page"""
    if request.method == 'POST':
        u_username = request.form.get('username')
        o_password = request.form.get('Old Password')
        n_password = request.form.get('New Password')
        user = put_in_list()
        print(user)
        content = []
        u_exist=name_existance(u_username)
        print(u_exist)
        p_exist=password_existance(o_password)
        print(p_exist)
        if u_exist is not None and p_exist is not None:
            for rec in user:
                item=str(rec).split(",")
                for i in item:
                    field=i.split(":")[0]
                    if field == u_username and  sha256_crypt.verify(o_password, p_exist[0]):
                        print(field)
                        r_field=i[1].replace(i[1], sha256_crypt.hash(n_password))
                        final=field+":"+r_field
                        content.append(final)
                    else:
                        content.append(rec)
        with open("credentials.txt", 'w', encoding="utf-8" ) as file:
            file.seek(0)
            for rows in content:
                file.write(rows)
                file.write("\n")
            return redirect("/dashboard")
    return render_template('update_password.html')



if __name__ == "__main__":
    APP.run(debug=True)
  