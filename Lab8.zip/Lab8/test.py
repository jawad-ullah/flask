from passlib.hash import sha256_crypt


print(sha256_crypt.verify("Navjaw@99","$5$rounds=535000$rLqgnaXVMtSpUeWW$rjQQJBOCNB/fh.KBp.sjrDUNJ6GkMreI2mUj8XSlTXC"))